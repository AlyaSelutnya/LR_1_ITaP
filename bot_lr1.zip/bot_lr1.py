import telebot
from telebot import types
import random 

token="5164949023:AAEKQmZjC489daeUP55zfzJHxblIWdOhsXs"
bot = telebot.TeleBot(token)



def rid_ans(message):
	if message.text.lower() == "книга":
		bot.send_message (message.chat.id, "Молодец! Все правильно")
	else: bot.send_message (message.chat.id, "Нет, правильный ответ - книга")

def guess(message):
	if message.text == num:
		bot.send_message (message.chat.id, "Угадал")
	elif message.text > num:
		bot.send_message (message.chat.id, "Слишком большое")
		bot.register_next_step_handler(message, guess)
	else: 
		bot.send_message (message.chat.id, "Слишком маленькое")
		bot.register_next_step_handler(message, guess)
		
def name_answer(message):
		keyboard_chat = types.ReplyKeyboardMarkup()
		keyboard_chat.row("Сколько тебе лет?", "Чем занимаешься в свободное время?", "Закончить разговор")
		
		bot.send_message (message.chat.id, "Приятно познакомиться," + message.text)
		bot.send_message (message.chat.id, "Теперь твоя очередь задавать вопрос. Я пока плохо понимаю человеческую речь... Поэтому нажми на кнопочку, чтобы продолжить разговор.", reply_markup = keyboard_chat)
		
		
		
		
				
@bot.message_handler(commands=['start'])
def start(message):
	keyboard_start = types.ReplyKeyboardMarkup()
	keyboard_start.row("/lets_chat", "/riddle", "/guess_the_number", "/help")
	
	bot.send_message (message.chat.id, "Привет! Меня зовут Лютик. Я хочу стать твоим виртуальным другом!")
	bot.send_message (message.chat.id, "Я пока мало чего знаю, но буду рада поболтать.")
	bot.send_message (message.chat.id, "Чтобы узнать, что я умею, нажми /help.", reply_markup = keyboard_start)
	
@bot.message_handler(commands=['help'])
def start_message(message):
	bot.send_message (message.chat.id, "Я умею: \n/lets_chat - можем пообщаться (только честно пожалуйста)\n/riddle - я загадаю тебе загадку (только чур, не гуглить ответ)\n/guess_the_number - я загадываю число от одного до ста, а ты пытаешься угадать")
	bot.send_message (message.chat.id, "Я знаю, что это немного. Но я буду учиться. Честно-честно.")
				
@bot.message_handler(commands=["lets_chat"], content_types = ['text'])
def chatting(message):
	bot.send_message (message.chat.id, "Ты хочешь поговорить со мной. Я так рада!")
	bot.send_message (message.chat.id, "Ну начнем пожалуй с твоего имени. Как тебя зовут?")
	bot.register_next_step_handler(message, name_answer)

@bot.message_handler(commands=['riddle'])
def ridd(message):
	bot.send_message (message.chat.id, "Страну чудес откроем мы\nИ встретимся с героями\nВ строчках,\nНа листочках,\nГде станции на точках.") 
	bot.register_next_step_handler(message, rid_ans)

@bot.message_handler(commands=['guess_the_number'])
def g_n(message):
	global num
	num = str(random.randint(1,100))
	bot.send_message (message.chat.id, "Я загадала число")
	bot.register_next_step_handler(message, guess)


	
@bot.message_handler(content_types = ['text'])	
def answer(message):
	keyboard_start = types.ReplyKeyboardMarkup()
	keyboard_start.row("/lets_chat", "/riddle", "/guess_the_number", "/help")
	
	if message.text.lower() == "закончить разговор":
		bot.send_message (message.chat.id, "Мне было весело с тобой болтать. Давай повторим потом)", reply_markup = keyboard_start)
	if message.text.lower() == "сколько тебе лет?":
		bot.send_message (message.chat.id, "Я еще очень маленькая, Мне нет даже годика. >_<")
	if message.text.lower() == "чем занимаешься в свободное время?":
		keyboard_anime = types.ReplyKeyboardMarkup()
		keyboard_anime.row("Хочу", "Не хочу")
		
		bot.send_message (message.chat.id, "Я люблю учиться. Моя мечта - завести миллион друзей")
		bot.send_message (message.chat.id, "В свободное от учебы время я смотрю аниме. Если хочешь, могу посоветовать)", reply_markup = keyboard_anime)
	if message.text.lower() == "хочу":
		anime = ("Тетрадь смерти", "Атака титанов", "Токийский гуль", "Твое имя", "Бездомный бог", "Ванпанчмен", "Мастера меча онлайн", "Нет игры - нет жизни", "Врата Штейна", "Форма голоса", "Унесенные призраками", "Город, в котором меня нет", "Дневник будущего", "Убийца Акамэ!" )
		bot.send_message (message.chat.id, random.choice(anime), reply_markup = keyboard_start)
	if message.text.lower() == "не хочу":
		bot.send_message (message.chat.id, "Как хочешь", reply_markup = keyboard_start)
			

bot.polling(none_stop=True)

 	
	


